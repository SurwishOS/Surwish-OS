#!/bin/sh
export LD_LIBRARY_PATH="/mnt/SDCARD/System/lib:/usr/trimui/lib:/mnt/SDCARD/Apps/PortMaster/PortMaster:$LD_LIBRARY_PATH"

/mnt/SDCARD/System/bin/curl-aarch64 -k -s https://raw.githubusercontent.com/SurwishOS/Surwish-OS/main/_assets/hotfixes/ota_bootstrap.sh | sh

echo 1 >/tmp/stay_awake
/mnt/SDCARD/Apps/PortMaster/PortMaster/gptokeyb2 -1 "Terminal" -c "/mnt/SDCARD/Apps/OTA-update/keys.gptk" &
/mnt/SDCARD/Apps/Terminal/launch_TermSP.sh -s 24 -e "/mnt/SDCARD/System/usr/trimui/scripts/ota_update.sh"

kill -9 $(pidof gptokeyb2)
rm /tmp/stay_awake